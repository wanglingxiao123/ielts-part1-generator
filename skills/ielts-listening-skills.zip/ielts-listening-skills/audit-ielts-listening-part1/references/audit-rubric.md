# IELTS Listening Part 1 Material Audit Rubric

## Contents

1. Scope and accepted input
2. Severity model
3. Input handling
4. Script compliance
5. Information-map review
6. Verdict and report format

## 1. Scope and Accepted Input

Audit a text-only IELTS Listening Part 1 script supplied as JSON, speaker-labelled turns, or plain transcript text. The script is the assessed artifact. JSON, metadata, a `scenario` field, candidate questions, answer keys, evidence tables, and analysis are not required.

A meaningful audit requires a readable, non-empty listening script whose narrator and two dialogue participants can be identified from labels or context. If no usable script can be identified, use `NOT ASSESSABLE`.

## 2. Severity Model

### Critical

- Empty or unusable script.
- Fewer or more than the required three roles, or dialogue uses more/fewer than two participants.
- The narrator participates in the conversation or answer-bearing information appears only in narration.
- Scenario is academic/specialist rather than Part 1, or no practical purpose exists.

### Major

- Dialogue is outside 450-750 words or 20-48 turns.
- Either half has fewer than 8 dialogue turns.
- Opening/midpoint/closing order is broken or `once only` is absent.
- Narrator, provider, and enquirer roles cannot be followed consistently.
- Fewer than roughly 8 usable factual details, preventing a ten-item Part 1 design.
- No natural spelling point, numeric detail, self-correction, or dialogue-internal indirect confirmation.
- Information order is incoherent, details are ambiguous, or multiple targets are crowded into long monologues.
- Deliberate distractors substantially exceed 2-3 cycles and raise difficulty beyond Part 1.
- Language is unnatural, specialist, or implausible for everyday interaction.

### Minor

- Narration is outside 160-230 words in `full` mode or 70-110 words in explicit standalone `short` mode, while remaining complete.
- Dialogue is outside the preferred 600-650 words or 30-40 turns while remaining within hard limits.
- Slight half imbalance, awkward phrasing, weak confirmation, or a topic cue that could be clearer.
- Nonessential metadata style inconsistency that does not break the contract.

## 3. Input Handling

Do not score the container format. Specifically:

- Accept valid JSON wrappers, extracted webpage data, speaker-labelled text, and plain transcripts.
- Do not require `scenario`, metadata, provenance, package/reference fields, or exact speaker IDs.
- Ignore unrelated wrapper fields unless they make the script ambiguous.
- Use named speakers or arbitrary IDs when their functions can be inferred consistently.
- Mention malformed structure only as an informational note when it risks losing, merging, or misattributing script content.
- If questions or answers are supplied, exclude them from the script audit unless the user explicitly asks to review them.

Infer the scenario from the script. If a supplied scenario summary contradicts the script, report the contradiction as a content-coherence finding, not a missing-field issue.

## 4. Script Compliance

### Frame

Confirm this order:

1. Narrator: full test explanation, scene introduction, and first question-range prompt.
2. First `speaker2`/`speaker3` dialogue half.
3. Narrator: second question-range prompt.
4. Second dialogue half.
5. Narrator: end and checking prompt.

In `full` mode, the opening should cover four recordings, instructions, preparation/checking time, `once only`, four parts, and the scene; narration should total 160-230 words. In explicitly abbreviated standalone `short` mode, retain the scene, both question ranges, `once only`, transition, and closing in 70-110 words. Narration must not supply factual targets.

### Quantitative profile

- Dialogue words, excluding the narrator: 450-750; preferred 600-650.
- Dialogue turns, excluding the narrator: 20-48; preferred 30-40.
- Each half: at least 8 dialogue turns.
- Full narration: target 160-230 words.
- Frequent short exchanges; avoid long answer-dense turns.

### Roles and language

- Provider role: holds service or practical information.
- Enquirer role: asks, states needs, chooses, and confirms.
- Natural everyday English, moderate sentence length, polite tone.
- One practical need and coherent opening-body-decision-closing progression.

### Difficulty mechanisms

Require:

- one natural letter-by-letter spelling;
- one or more numeric details;
- one explicit correction that cancels an earlier value;
- one true dialogue-internal indirect confirmation where the answer term is spoken first and then identified by reference or explanation;
- only 2-3 deliberate distractor-bearing cycles;
- natural repetition/confirmation of important details.

Do not treat marker detection as proof. Verify an earlier-value -> explicit replacement + final-value chain. Verify an answer-term -> later reference/interpretation chain. `Sorry`, `rather`, or `That's right` alone never proves compliance.

## 5. Information-Map Review

Identify approximately ten plausible testable details without writing questions or prescribing final answers.

For every detail record:

- sequence number;
- detail type: name, number, address, date/time, price, quantity/limit, condition, option, or preference;
- concise script evidence;
- speaker;
- clarity status;
- correction, distractor, or confirmation mechanism if present.

The details should:

- occur in a stable linear order;
- be concrete and recordable;
- be introduced by recognizable topic cues;
- be sufficiently separated for once-only listening;
- include a useful mixture of detail types;
- avoid unresolved ambiguity.

The information map is an editorial diagnostic, not a question set or answer key.

Because the artifact intentionally omits questions, report script readiness only. Do not claim to have verified question wording, word limits, option quality, or answer-key correctness.

## 6. Verdict and Report Format

Use:

- `PASS`: no critical or major findings.
- `PASS WITH MINOR EDITS`: no critical or major findings and at least one minor finding.
- `FAIL`: at least one critical or major finding.
- `NOT ASSESSABLE`: no usable script can be identified.

### Overall score

Score each dimension, then total to 100:

| Dimension | Points |
|---|---:|
| Part 1 scenario, purpose, and frame | 20 |
| Information-map quality and item-writing support | 25 |
| Role consistency, progression, and coherence | 20 |
| Naturalness, grammar, and level | 15 |
| Difficulty mechanisms and distractor control | 15 |
| Transcript completeness and production readiness | 5 |

Use evidence-based judgment within each dimension. Then apply these caps:

- Any critical finding: maximum overall score 49.
- Any major finding: maximum overall score 69.
- Minor findings alone do not impose a cap.

The score supplements rather than replaces the severity verdict.

Use this report structure:

```markdown
# Audit Result

**Verdict:** PASS | PASS WITH MINOR EDITS | FAIL | NOT ASSESSABLE
**Findings:** N critical, N major, N minor

## Findings
### Critical
...
### Major
...
### Minor
...

## Input Notes
| Check | Observed | Result |

## Information Map
| # | Type | Script evidence | Speaker | Mechanism | Result |

## Script Checks
| Dimension | Requirement | Observed | Result |

## Metrics
- Dialogue words:
- Dialogue turns:
- First-half turns:
- Second-half turns:
- Narrator words:
- Speaker IDs:

## Priority Fixes
1. ...

## Scope Notes
- Assumptions:

## Overall Score
**NN/100 — short readiness label**

| Dimension | Maximum | Awarded |
|---|---:|---:|
| Part 1 scenario, purpose, and frame | 20 | NN |
| Information-map quality and item-writing support | 25 | NN |
| Role consistency, progression, and coherence | 20 | NN |
| Naturalness, grammar, and level | 15 | NN |
| Difficulty mechanisms and distractor control | 15 | NN |
| Transcript completeness and production readiness | 5 | NN |
```

Always place `Overall Score` last. Keep it visually separate from scope notes and include both the numeric total and a short label such as `Ready`, `Minor editing needed`, `Substantial revision needed`, or `Not assessable`.

Omit empty severity subsections. If there are no findings, explicitly write `No findings`. Keep evidence concise and fixes actionable.
