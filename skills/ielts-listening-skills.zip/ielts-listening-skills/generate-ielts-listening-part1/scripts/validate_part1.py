#!/usr/bin/env python3
"""Validate IELTS Part 1 material JSON and its private item blueprint."""

from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime
from pathlib import Path

TOP_KEYS = {"model", "extracted_at", "test_package", "content_kind", "source_htmls", "listening_material_parts"}
PART_KEYS = {"reference", "test_package", "scenario", "script", "source_htmls"}
SCRIPT_KEYS = {"reference", "test_package", "turns", "speaker_count"}
FORBIDDEN_KEYS = {"candidate_questions", "questions", "answer_key", "answers", "item_evidence", "analysis", "quality_check"}
SPELLING_RE = re.compile(r"\b(?:[A-Z]\s*[-,]\s*){2,}[A-Z]\b|\b[A-Z](?:-[A-Z]){2,}\b|\bdouble\s+[A-Z]\b", re.I)
NUMBER_RE = re.compile(r"(?:[$£€]\s*\d|\b\d+\b)")
FIRST_RANGE_RE = re.compile(r"questions?\s+1\s*(?:to|[-~–])\s*(\d+)", re.I)
SECOND_RANGE_RE = re.compile(r"questions?\s+(\d+)\s*(?:to|[-~–])\s*10", re.I)


def words(value: str) -> int:
    return len(re.findall(r"\b[\w'-]+\b", value))


def exact_keys(value: dict, expected: set[str], label: str, errors: list[str]) -> None:
    missing, extra = sorted(expected - value.keys()), sorted(value.keys() - expected)
    if missing:
        errors.append(f"{label} missing fields: {missing}")
    if extra:
        errors.append(f"{label} unexpected fields: {extra}")


def forbidden_paths(value: object, path: str = "$") -> list[str]:
    found: list[str] = []
    if isinstance(value, dict):
        for key, child in value.items():
            if key.lower() in FORBIDDEN_KEYS:
                found.append(f"{path}.{key}")
            found.extend(forbidden_paths(child, f"{path}.{key}"))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            found.extend(forbidden_paths(child, f"{path}[{index}]"))
    return found


def read_json(path: Path, label: str) -> object:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"invalid {label} JSON: {exc}") from exc


def find_turn(turns: list[dict], phrase: object) -> int:
    needle = str(phrase or "").casefold()
    if not needle:
        return -1
    for index, turn in enumerate(turns):
        if turn.get("speaker") != "speaker1" and needle in str(turn.get("text", "")).casefold():
            return index
    return -1


def find_occurrence(turns: list[dict], phrase: object) -> tuple[int, int]:
    needle = str(phrase or "").casefold()
    if not needle:
        return (-1, -1)
    for index, turn in enumerate(turns):
        if turn.get("speaker") == "speaker1":
            continue
        position = str(turn.get("text", "")).casefold().find(needle)
        if position >= 0:
            return (index, position)
    return (-1, -1)


def validate_blueprint(blueprint: object, turns: list[dict], midpoint: int, first_end: int, second_start: int, errors: list[str]) -> str:
    if not isinstance(blueprint, dict):
        errors.append("blueprint must be an object")
        return "full"
    exact_keys(blueprint, {"narration_mode", "split_after", "items", "correction", "indirect_confirmation"}, "blueprint", errors)
    mode = blueprint.get("narration_mode")
    if mode not in {"full", "short"}:
        errors.append("blueprint.narration_mode must be full or short")
        mode = "full"
    split_after = blueprint.get("split_after")
    if split_after not in {5, 6} or split_after != first_end or second_start != first_end + 1:
        errors.append("blueprint split must match a contiguous 1-5/6-10 or 1-6/7-10 narration split")
    items = blueprint.get("items")
    if not isinstance(items, list) or len(items) != 10:
        errors.append("blueprint.items must contain exactly 10 items")
        items = []
    positions, types, distractors, confirmations = [], set(), 0, 0
    for number, item in enumerate(items, 1):
        label = f"blueprint.items[{number - 1}]"
        if not isinstance(item, dict):
            errors.append(f"{label} must be an object")
            continue
        exact_keys(item, {"number", "group", "type", "target", "evidence", "distractor", "confirmed"}, label, errors)
        if item.get("number") != number:
            errors.append(f"{label}.number must be {number}")
        expected_group = 1 if number <= split_after else 2
        if item.get("group") != expected_group:
            errors.append(f"{label}.group must be {expected_group}")
        target, evidence = item.get("target"), item.get("evidence")
        if not isinstance(target, str) or not target.strip() or not isinstance(evidence, str) or not evidence.strip():
            errors.append(f"{label} target/evidence must be non-empty strings")
            continue
        if target.casefold() not in evidence.casefold():
            errors.append(f"{label}.target must occur inside evidence")
        position = find_turn(turns, evidence)
        if position < 0:
            errors.append(f"{label}.evidence not found in dialogue")
        else:
            positions.append(position)
            if (expected_group == 1 and position >= midpoint) or (expected_group == 2 and position <= midpoint):
                errors.append(f"{label}.evidence is in the wrong dialogue half")
        if isinstance(item.get("type"), str):
            types.add(item["type"].casefold())
        if item.get("distractor") is True:
            distractors += 1
        elif item.get("distractor") is not False:
            errors.append(f"{label}.distractor must be boolean")
        if item.get("confirmed") is True:
            confirmations += 1
        elif item.get("confirmed") is not False:
            errors.append(f"{label}.confirmed must be boolean")
    if len(positions) == 10 and (positions != sorted(positions) or len(set(positions)) != 10):
        errors.append("item evidence must occur in strictly increasing, distinct dialogue turns")
    if len(types) < 4:
        errors.append("blueprint must use at least four detail types")
    if not 2 <= distractors <= 3:
        errors.append(f"blueprint must mark 2-3 distractor items; found {distractors}")
    if confirmations < 1:
        errors.append("blueprint must mark at least one confirmed item")
    correction = blueprint.get("correction")
    if not isinstance(correction, dict):
        errors.append("blueprint.correction must be an object")
    else:
        exact_keys(correction, {"earlier", "final", "marker"}, "blueprint.correction", errors)
        earlier, final, marker = (find_occurrence(turns, correction.get(key)) for key in ("earlier", "final", "marker"))
        if min(earlier[0], final[0], marker[0]) < 0 or not earlier < marker < final:
            errors.append("correction must contain earlier value, then replacement marker, then final value")
    indirect = blueprint.get("indirect_confirmation")
    if not isinstance(indirect, dict):
        errors.append("blueprint.indirect_confirmation must be an object")
    else:
        exact_keys(indirect, {"answer_term", "reference_phrase"}, "blueprint.indirect_confirmation", errors)
        answer = find_turn(turns, indirect.get("answer_term"))
        reference = find_turn(turns, indirect.get("reference_phrase"))
        if answer < 0 or reference < 0 or answer >= reference:
            errors.append("indirect answer term must occur before its reference phrase")
    return str(mode)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("material", type=Path)
    parser.add_argument("--blueprint", required=True, type=Path)
    args = parser.parse_args()
    try:
        data, blueprint = read_json(args.material, "material"), read_json(args.blueprint, "blueprint")
    except ValueError as exc:
        print(f"ERROR: {exc}")
        return 1
    errors, warnings = [], []
    if not isinstance(data, dict):
        print("ERROR: top-level JSON must be an object")
        return 1
    exact_keys(data, TOP_KEYS, "top level", errors)
    if not isinstance(data.get("model"), str) or not data.get("model", "").strip():
        errors.append("model must be non-empty")
    if not isinstance(data.get("test_package"), str) or not data.get("test_package", "").strip():
        errors.append("test_package must be non-empty")
    if data.get("content_kind") != "listening_material":
        errors.append("content_kind must be listening_material")
    if data.get("source_htmls") != []:
        errors.append("top-level source_htmls must be []")
    try:
        datetime.fromisoformat(str(data.get("extracted_at", "")).replace("Z", "+00:00"))
    except ValueError:
        errors.append("extracted_at must be ISO 8601")
    forbidden = forbidden_paths(data)
    if forbidden:
        errors.append(f"forbidden output fields: {forbidden}")
    parts = data.get("listening_material_parts")
    if not isinstance(parts, list) or len(parts) != 1:
        errors.append("listening_material_parts must contain exactly one object")
        parts = []
    total_words = total_turns = 0
    for part in parts:
        if not isinstance(part, dict):
            errors.append("part must be an object")
            continue
        exact_keys(part, PART_KEYS, "part", errors)
        if part.get("reference") != "Part 1" or part.get("test_package") != data.get("test_package"):
            errors.append("part reference/package is invalid")
        if not isinstance(part.get("scenario"), str) or not part.get("scenario", "").strip():
            errors.append("scenario must be non-empty")
        if part.get("source_htmls") != []:
            errors.append("part.source_htmls must be []")
        script = part.get("script")
        if not isinstance(script, dict):
            errors.append("script must be an object")
            continue
        exact_keys(script, SCRIPT_KEYS, "script", errors)
        if script.get("reference") != part.get("reference") or script.get("test_package") != part.get("test_package"):
            errors.append("script reference/package must match part")
        if script.get("speaker_count") != 3:
            errors.append("speaker_count must be 3")
        turns = script.get("turns")
        if not isinstance(turns, list) or not turns:
            errors.append("turns must be non-empty")
            continue
        for index, turn in enumerate(turns):
            if not isinstance(turn, dict):
                errors.append(f"turn[{index}] must be an object")
                continue
            exact_keys(turn, {"speaker", "text"}, f"turn[{index}]", errors)
            if turn.get("speaker") not in {"speaker1", "speaker2", "speaker3"}:
                errors.append(f"turn[{index}] has invalid speaker")
            if not isinstance(turn.get("text"), str) or not turn.get("text", "").strip():
                errors.append(f"turn[{index}] has empty text")
        if {turn.get("speaker") for turn in turns if isinstance(turn, dict)} != {"speaker1", "speaker2", "speaker3"}:
            errors.append("speaker set must be exactly speaker1/2/3")
        narrator = [i for i, turn in enumerate(turns) if turn.get("speaker") == "speaker1"]
        if len(narrator) != 3:
            errors.append(f"exactly three narrator turns required; found {len(narrator)}")
            continue
        if narrator[0] != 0 or narrator[-1] != len(turns) - 1:
            errors.append("speaker1 must open and close the script")
        opening, midpoint_text, closing = (turns[i]["text"] for i in narrator)
        first, second = FIRST_RANGE_RE.search(opening), SECOND_RANGE_RE.search(midpoint_text)
        first_end, second_start = (int(first.group(1)), int(second.group(1))) if first and second else (0, 0)
        if first_end not in {5, 6} or second_start != first_end + 1:
            errors.append("narration must state 1-5/6-10 or 1-6/7-10")
        if "once only" not in opening.casefold():
            errors.append("opening must include once only")
        if not re.search(r"end of (?:section one|part 1|part one)", closing, re.I) or "check your answers" not in closing.casefold():
            errors.append("closing must identify Part 1 end and checking")
        if not re.search(r"(?:turn|move on) to (?:section|part) (?:two|2)", closing, re.I):
            errors.append("closing must direct candidates to Part/Section 2")
        mode = validate_blueprint(blueprint, turns, narrator[1], first_end, second_start, errors)
        narration = " ".join(turns[i]["text"] for i in narrator)
        if mode == "full":
            for phrase in ("four different recordings", "four parts"):
                if phrase not in opening.casefold():
                    errors.append(f"full opening must include {phrase!r}")
            if not 160 <= words(narration) <= 230:
                errors.append(f"full narration must be 160-230 words; found {words(narration)}")
        elif not 70 <= words(narration) <= 110:
            errors.append(f"short narration must be 70-110 words; found {words(narration)}")
        dialogue_turns = [turn for turn in turns if turn.get("speaker") != "speaker1"]
        dialogue = " ".join(turn["text"] for turn in dialogue_turns)
        total_words, total_turns = total_words + words(dialogue), total_turns + len(dialogue_turns)
        if not 450 <= words(dialogue) <= 750:
            errors.append(f"dialogue words outside 450-750: {words(dialogue)}")
        elif not 600 <= words(dialogue) <= 650:
            warnings.append(f"dialogue words outside preferred 600-650: {words(dialogue)}")
        if not 20 <= len(dialogue_turns) <= 48:
            errors.append(f"dialogue turns outside 20-48: {len(dialogue_turns)}")
        elif not 30 <= len(dialogue_turns) <= 40:
            warnings.append(f"dialogue turns outside preferred 30-40: {len(dialogue_turns)}")
        before = sum(i < narrator[1] for i, turn in enumerate(turns) if turn.get("speaker") != "speaker1")
        after = len(dialogue_turns) - before
        if before < 8 or after < 8:
            errors.append(f"each half needs 8 turns; found {before}/{after}")
        if not SPELLING_RE.search(dialogue):
            errors.append("no spelling sequence detected")
        if not NUMBER_RE.search(dialogue):
            errors.append("no numeric information detected")
    print(f"Dialogue words: {total_words}")
    print(f"Dialogue turns: {total_turns}")
    for message in errors:
        print(f"ERROR: {message}")
    for message in warnings:
        print(f"WARNING: {message}")
    if errors or warnings:
        print(f"FAIL: {len(errors)} error(s), {len(warnings)} warning(s)")
        return 1
    print("PASS: 0 errors, 0 warnings")
    return 0


if __name__ == "__main__":
    sys.exit(main())
