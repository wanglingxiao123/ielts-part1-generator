# IELTS Listening Part 1 Script Specification

## Contents

1. Content profile
2. Script architecture
3. Information design
4. Language and speaker roles
5. JSON output contract
6. Final private checklist

## 1. Content Profile

- Use an everyday/social-life setting, not academic or specialist content.
- Center one clear practical need, such as booking, service enquiry, registration, accommodation, job enquiry, complaint/refund, community participation, health service, driving lessons, or shipping.
- Use exactly two dialogue participants plus the exam narrator.
- Make the exchange genuinely two-way. Usually the enquirer asks and chooses while the provider supplies organized factual details.
- State that the recording is heard `once only`.
- Internally design approximately ten testable details in two groups, although no questions or answers appear in the output.
- Use original content only.

## 2. Script Architecture

### Exam frame

Use this sequence:

1. `speaker1`: whole-test introduction in `full` mode, then scenario introduction and first reading prompt; omit only the whole-test boilerplate in explicit `short` mode.
2. `speaker2` and `speaker3`: first dialogue segment.
3. `speaker1`: midpoint prompt for the second question group.
4. `speaker2` and `speaker3`: second dialogue segment.
5. `speaker1`: end-of-Part-1 checking prompt.

In default `full` mode, the opening should naturally cover four recordings, answer instructions, preparation/checking time, `once only`, four parts, the Part 1 scenario, and the first question range. In explicit `short` mode, retain `once only`, the scenario, and first range. The midpoint gives the second range. The closing identifies the end of Part 1, checking time, and transition to Part 2.

### Dialogue frame

Follow this progression:

1. Greeting and provider identity.
2. Enquirer states the practical purpose.
3. Sequential information micro-cycles.
4. Comparison or decision.
5. Thanks and next step.

Use the micro-cycle:

`question/topic cue -> target detail -> optional correction, spelling, repetition, or confirmation`

Keep the ten private target details in strict order. Prefer one target per cycle and use clear topic changes.

### Length and pacing

- Dialogue words, excluding `speaker1`: 450-750; target 600-650.
- Dialogue turns, excluding `speaker1`: 20-48; target 30-40.
- Each dialogue half: at least 8 turns.
- Narration: 160-230 words in `full` mode; 70-110 words in explicitly requested standalone `short` mode.
- Favor short turns and frequent exchange over long information-dense monologues.

## 3. Information Design

Privately plan ten recordable details selected from:

- spelled name or proper noun;
- telephone/reference number;
- address or house number;
- price or total;
- date, time, or shift;
- quantity, size, weight, or maximum;
- condition, eligibility, or requirement;
- option or preference.

Include:

- at least one natural letter-by-letter spelling;
- at least one numeric target;
- natural repetition or confirmation;
- one clear self-correction in which a final value replaces an earlier value;
- one dialogue-internal indirect confirmation.

For indirect confirmation, explicitly say the answer term first, then refer to it:

```text
speaker2: Would you like it by email or by post?
speaker3: The latter, please. I would rather read it on paper.
```

Use only 2-3 deliberate distractor-bearing cycles. Valid mechanisms are self-correction, option comparison, negation, and conditional limitation. Signal the final information clearly. Keep Part 1 accessible.

Before finalizing, scan every dialogue turn independently of the blueprint. Count all earlier values later replaced, rejected alternatives, selection-driving comparisons, exclusions, and applicability-changing conditions. The full-script census must equal the 2-3 items marked as distractors. If the script contains an additional unmarked trap, simplify or remove it.

## 4. Language and Speaker Roles

- `speaker1`: narrator only; never provides testable factual answers.
- `speaker2`: service provider, receptionist, adviser, or other information holder.
- `speaker3`: customer, student, applicant, or other enquirer.
- Use exactly these IDs; do not use names in the `speaker` field.
- Keep spoken English polite, natural, and everyday.
- Use moderate sentence length and light conversational markers such as `Of course`, `Let me check`, and `That's right`.
- Avoid specialist terminology, rare idioms, implausible details, and artificial lists.

## 5. JSON Output Contract

Return only valid JSON with this shape:

```json
{
  "model": "known-model-id-or-unspecified",
  "extracted_at": "2026-07-22T07:28:21.905274+00:00",
  "test_package": "Test 1",
  "content_kind": "listening_material",
  "source_htmls": [],
  "listening_material_parts": [
    {
      "reference": "Part 1",
      "test_package": "Test 1",
      "scenario": "A student calls an international shipping company to ask about sending luggage abroad.",
      "script": {
        "reference": "Part 1",
        "test_package": "Test 1",
        "turns": [
          {
            "speaker": "speaker1",
            "text": "This is the IELTS listening test..."
          },
          {
            "speaker": "speaker2",
            "text": "Hello, Move It Shipping."
          },
          {
            "speaker": "speaker3",
            "text": "Hi. I'd like some information about your services, please."
          }
        ],
        "speaker_count": 3
      },
      "source_htmls": []
    }
  ]
}
```

Contract rules:

- Set `content_kind` exactly to `listening_material`.
- Use a non-empty `listening_material_parts` array.
- Include a non-empty `scenario` in every part.
- Keep top-level, part-level, and script-level package/reference values consistent.
- Use one turn object per spoken turn with only `speaker` and `text`.
- Use exactly `speaker1`, `speaker2`, and `speaker3`.
- Count the narrator in `speaker_count`; therefore its value is `3`.
- Use JSON strings with escaped quotation marks and no trailing commas.
- For original generation, use `[]` for both `source_htmls` arrays.
- Do not include `candidate_questions`, `questions`, `answer_key`, `answers`, `item_evidence`, `analysis`, or `quality_check`.

### Private blueprint

Create a separate temporary JSON file for validation. Never include it in the delivered material:

```json
{
  "narration_mode": "full",
  "split_after": 5,
  "items": [
    {
      "number": 1,
      "group": 1,
      "type": "name",
      "target": "Patel",
      "evidence": "The surname is P-A-T-E-L.",
      "distractor": false,
      "confirmed": true
    }
  ],
  "correction": {
    "earlier": "half past nine",
    "final": "nine o'clock",
    "marker": "Actually"
  },
  "indirect_confirmation": {
    "answer_term": "a pannier",
    "reference_phrase": "the latter"
  }
}
```

Include exactly 10 items numbered 1-10. Use a 1-5 / 6-10 or 1-6 / 7-10 split. Every target must occur inside its evidence, every evidence phrase must occur in a distinct dialogue turn, and evidence positions must strictly increase. Use at least four detail types, exactly 2-3 distractor items, and at least one confirmed item. The correction's earlier value must precede its final value and marker. The indirect answer term must precede its reference phrase.

The `distractor` booleans must be a complete census, not merely selected examples. Recheck the entire script for unmarked alternatives, corrections, negations, and qualifiers.

## 6. Final Private Checklist

- [ ] Everyday scenario and one clear practical need.
- [ ] `scenario` accurately summarizes the generated script.
- [ ] Exactly `speaker1`, `speaker2`, and `speaker3`; `speaker_count` is 3.
- [ ] Full narration/dialogue/midpoint/dialogue/closing order.
- [ ] Opening explicitly contains `once only`.
- [ ] Ten private target details occur in order across two balanced halves.
- [ ] At least one spelling point and one numeric point.
- [ ] One clear self-correction and one true dialogue-internal indirect confirmation.
- [ ] Only 2-3 deliberate distractor cycles.
- [ ] Dialogue is 450-750 words and 20-48 turns; each half has at least 8 turns.
- [ ] Spoken English is natural and appropriate for Part 1.
- [ ] JSON parses and matches the contract.
- [ ] Private blueprint passes deterministic order, split, evidence, correction, indirect-reference, and distractor checks.
- [ ] Output contains only listening material, with no questions, answers, or analysis.
