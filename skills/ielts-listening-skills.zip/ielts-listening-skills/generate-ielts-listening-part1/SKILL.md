---
name: generate-ielts-listening-part1
description: Generate and validate original text-only IELTS Listening Part 1 scripts as structured JSON containing metadata, a scenario field, speaker-labelled turns, and speaker count. Use when a user asks for an IELTS Listening Section/Part 1 listening material, dialogue, recording script, or scenario-based practice transcript. Return only the listening material JSON, without candidate questions, answer keys, item analysis, evidence tables, or quality-check commentary. Do not use for audio production or academic Listening Parts 2-4.
---

# Generate IELTS Listening Part 1

Create an original, internally coherent Part 1 recording script and return only the required JSON artifact.

## Required Reference

Read [references/specification.md](references/specification.md) completely before generating a script. It defines the authoring constraints and exact JSON contract.

## Workflow

1. Resolve metadata and scenario.
   - Use the user's scenario and package/reference values when supplied.
   - Otherwise choose one realistic everyday scenario, set `test_package` to `Test 1`, and set `reference` to `Part 1`.
   - Write `scenario` as one concise Chinese or English sentence that identifies the participants, practical need, and setting.
   - Use the actual model identifier when known; otherwise use `unspecified`.
   - Set `extracted_at` to the current UTC time in ISO 8601 format.
   - For original material, set every `source_htmls` field to `[]`.

2. Build a private ten-item blueprint.
   - Plan ten factual targets in strict order, divided into two groups such as 1-5 / 6-10.
   - Include at least one spelled name/proper noun, one numeric target, one genuine self-correction, and one dialogue-internal indirect confirmation.
   - Use only 2-3 deliberate distractor-bearing cycles.
   - Save the blueprint as temporary JSON using the schema in the reference. It is a validation sidecar, not part of the delivered artifact.
   - Keep this blueprint private. Do not include questions, answers, analysis, evidence, or quality checks in the output.

3. Draft the recording script.
   - Use `speaker1` only for narration, `speaker2` for the service/information provider, and `speaker3` for the enquirer.
   - Use exactly these three speaker IDs and set `speaker_count` to `3`.
   - Follow this order: full test/scene introduction and first reading prompt; first dialogue half; midpoint reading prompt; second dialogue half; closing check prompt.
   - Make answer-bearing information follow the private target order without returning to earlier targets.
   - Keep narration free of answer content.
   - Target 450-750 dialogue words, preferably 600-650; 20-48 dialogue turns, preferably 30-40; and at least 8 dialogue turns in each half.
   - Use short, natural, polite turns and everyday English.

4. Validate semantics privately.
   - Check that all ten private targets are unique and recoverable.
   - Check that answer terms occur explicitly before any indirect reference to them.
   - Check spelling, numeric details, correction, dialogue-internal paraphrase, confirmation, and distractor density.
   - Perform an adversarial distractor census over every dialogue turn. Count every self-correction, rejected alternative, option comparison used to select an answer, negation/exclusion, and condition that changes applicability.
   - Ensure the census contains exactly 2-3 cycles and matches the items marked `distractor: true` in the private blueprint. Treat an unmarked cycle as a validation failure and revise the script.
   - Check that no dialogue turn carries more than one private target and that no long provider turn crowds several potential answers.
   - Do not expose this analysis in the result.

5. Validate the JSON.
   - Save the output as `.json`.
   - Run `python3 scripts/validate_part1.py <output.json> --blueprint <private-blueprint.json>`.
   - Fix every error and warning before returning the artifact.
   - Never include the private blueprint in the delivered JSON.
   - After deterministic validation, reread the complete script once without relying on blueprint labels and repeat the semantic checklist.

## Output Rules

- Return one valid JSON object conforming exactly to the reference schema.
- Return no Markdown fences, introduction, explanation, questions, answer key, evidence table, or quality report around the JSON.
- Preserve turn order; store one spoken turn per `{speaker, text}` object.
- Do not add named-speaker fields. Speaker identities may be introduced naturally in turn text.
- Default to `full` narration. Use `short` only when the user explicitly requests an abbreviated standalone frame.
- Do not claim official IELTS/Cambridge authorship or reproduce proprietary scripts.
